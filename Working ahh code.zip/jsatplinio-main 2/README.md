# JS@Plinio
<hr>
<h1 style="text-align: center;">Da sistemare:</h1>
<p>- Contatore in alto a destra</p>
<p>- Pulsante continua in automatico alla fine del countdown</p>
